// Controlador
import java.util.Scanner;

public class Controlador {
    private Modelo modelo;
    private Visualizacao visualizacao;

    public Controlador(Modelo modelo, Visualizacao visualizacao) {
        this.modelo = modelo;
        this.visualizacao = visualizacao;
    }

    public void iniciar() {
        Scanner scanner = new Scanner(System.in);

        // Entrada dos números
        int[] numeros = new int[10];
        System.out.println("Digite 10 números:");
        for (int i = 0; i < 10; i++) {
            numeros[i] = scanner.nextInt();
        }
        modelo.setNumeros(numeros);

        // Escolha do método de ordenação
        System.out.println("Escolha o método de ordenação (BubbleSort(1) ou InsertionSort(2)):");
        String metodo = scanner.next();

        // Ordenação e exibição dos números
        if (metodo.equalsIgnoreCase("1")) {
            modelo.bubbleSort();
        } else if (metodo.equalsIgnoreCase("2")) {
            modelo.insertionSort();
        } else {
            System.out.println("Método de ordenação inválido.");
            return;
        }

        visualizacao.exibirNumeros(modelo.getNumeros());
    }
}