// Visualizacao
public class Visualizacao {
    public void exibirNumeros(int[] numeros) {
        System.out.println("Números ordenados:");
        for (int num : numeros) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}