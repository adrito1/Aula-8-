// Classe principal
public class Main {
    public static void main(String[] args) {
        Modelo modelo = new Modelo();
        Visualizacao visualizacao = new Visualizacao();
        Controlador controlador = new Controlador(modelo, visualizacao);
        controlador.iniciar();
    }
}