// Modelo
public class Modelo {
    private int[] numeros;

    public Modelo() {
        // Não é necessário definir o tamanho fixo do array aqui
    }

    public void setNumeros(int[] numeros) {
        this.numeros = numeros;
    }

    public int[] getNumeros() {
        return numeros;
    }

    public void bubbleSort() {
        // Implementação do Bubble Sort
    }

    public void insertionSort() {
        // Implementação do Insertion Sort
    }
}